<div class='container' style='background:#fff;
      background-size: cover;
      background-position: center;
      min-height: 600px;
      width: 100%;
      padding: 30px 0px;
      text-align: center;'>
        <!-- <a href='www.itike.rw'><img src='https://www.itike.rw/images/logo-name.png' height='50'></a> -->
        <div class='email-container' style='
        padding: 20px 0px;
        margin-top: 10px;
        width: 95%;
        max-width: 500px;
        margin: auto;'>
          <div class='email-header' style='
          padding: 20px 0px;
          background:#FDAE2B;
          background: #FDAE2B !important;
          color: #000;
          font-size: 20px;
          font-family: ubuntu;
          position: relative;'>
           New Order : #11332
          </div>
          <div style='background: rgba(255,255,255,0.9);
          min-height: 250px;
          padding: 20px;
          text-align: left;
          font-family: arial;
          font-size: 14px;
          line-height: 20px;'>
          <div class='email-body' style='
            width:98%;
            margin:auto; position:relative;'>
            <p>Hello</p>
            <!-- &#x22; &#x22; -->
            <p>You have received the following order from user</p>
            <p style="color:#FBB961;"> [Order #11332 ](Date)</p>

            <div style='position:relative'>
            <table border="1" style="border-collapse: collapse;"  width="100%">
                <tr><td width="60%"><b>Product</b></td><td width="20%"><b>Quantity</b></td><td width="20%"><b>Price</b></td></tr>
                <tr>
                    <td style="font-size:14px;">
                        <p>Online Product</p>
                        <p><b>Product Link :</b> product link</p>
                        <p><b>Product Price :</b> product price</p>
                        <p><b>Ships to Rwanda?:</b> product link</p>
                    </td>
                    <td style="font-size:14px;">1</td>
                    <td style="font-size:14px;">$360</td></tr>
                    <tr><td style="font-size:14px;" colspan="2"><b>Subtotal : </b></td><td style="font-size:14px;">$360</td></tr>
                    <tr><td style="font-size:14px;" colspan="2"><b>Payment method : </b></td><td style="font-size:14px;">money transfer</td></tr>
                    <tr><td style="font-size:14px;" colspan="2"><b>Total : </b></td><td style="font-size:14px;">$360</td></tr>
            </table>

            <p style="color:#FBB961;texe-align:center;"><b>Billing Address</b></p>
            <div width="100%" style="border: 1px solid black;">
            <center>Umutesi orlane<br>
            Telephone number<br>
            Email<br>
            </center>
            </div>
            </div>
            </div>
            <br>
            <p>Congratilations on the sale</p>
          </div>
          </div>
          <!-- <div class='email-footer' style='
          padding: 20px 0px;
          background:rgb(19,30,56);
          background: #000 !important;
          color: #fff;
          font-size: 13px;
          font-family: ubuntu;
          position: relative;'>
            Arthur Nation Team  - Proudly powered by <a style='color: #fff;' target='_blank' href='https://www.itdevs.rw'>IT Devs</a>
          </div> -->
        </div>
    </div>