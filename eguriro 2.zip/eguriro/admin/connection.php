<?php $serveraddress = "localhost";
	$username = "root";
	$password =  "mysql";
	$dbname =  "eguriro";

    $conn = mysqli_connect($serveraddress, $username, $password, $dbname);
    
    ?>