<nav class="pcoded-navbar">
<div class="nav-list">
<div class="pcoded-inner-navbar main-menu">
<div class="pcoded-navigation-label">Navigation</div>
<ul class="pcoded-item pcoded-left-item">
<li class="">
<a href="home.php" class="waves-effect waves-dark">
<span class="pcoded-micon"><i class="feather icon-home"></i></span>
<span class="pcoded-mtext">Dashboard</span>
</a>
</li>
<li class="">
<a href="order_report.php" class="waves-effect waves-dark">
<span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
<span class="pcoded-mtext">Order's Report</span>
</a>
</li>

<li class="pcoded-hasmenu">
<a href="javascript:void(0)" class="waves-effect waves-dark">
<span class="pcoded-micon">
<i class="feather icon-menu"></i>
</span>
<span class="pcoded-mtext">Product</span>
</a>

<ul class="pcoded-submenu">
<li class="">
<a href="new_product.php" class="waves-effect waves-dark">
<span class="pcoded-mtext">New Product</span>
</a>
</li>
<li class="">
<a href="manage_product.php" class="waves-effect waves-dark">
<span class="pcoded-mtext">Manage product</span>
</a>
</li>
</ul>
</li>



<li class="pcoded-hasmenu">
<a href="javascript:void(0)" class="waves-effect waves-dark">
<span class="pcoded-micon">
<i class="feather icon-menu"></i>
</span>
<span class="pcoded-mtext">Out orders report</span>
</a>

<ul class="pcoded-submenu">
<li class="">
<a href="out_daily_report.php" class="waves-effect waves-dark">
<span class="pcoded-mtext">Daily report</span>
</a>
</li>
<li class="">
<a href="out_order_report.php" class="waves-effect waves-dark">
<span class="pcoded-mtext">Manage report </span>
</a>
</li>
</ul>
</li>




</ul>



</div>
</div>
</nav>